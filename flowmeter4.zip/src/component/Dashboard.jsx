import React, { useState } from "react";

import { useNavigate } from "react-router-dom";

function Dashboard() {
  const navigate = useNavigate();

  const userName = JSON.parse(localStorage.getItem("users"));

  const handleLogout = () => {
    localStorage.removeItem("loggedin");
    navigate("/login");
  };

  return (
    <>
      <nav class="p-3 border-gray-200   rounded bg-blue-500 dark:bg-gray-800 dark:border-gray-700">
        <div class=" flex flex-wrap items-center justify-between mx-auto">
          <div class="hidden w-full md:block md:w-auto" id="navbar-solid-bg">
            <ul class="flex flex-col mt-4 rounded-lg bg-gray-50 md:flex-row md:space-x-8 md:mt-0 md:text-sm md:font-medium md:border-0 md:bg-transparent dark:bg-gray-800 md:dark:bg-transparent dark:border-gray-700">
              <li>
                <a
                  href="#"
                  class="block font-bold text-lg py-2 pl-3 pr-4 text-white bg-bgreen-700 rounded md:bg-transparent md:text-white md:p-0 md:dark:text-white dark:bg-blue-600 md:dark:bg-transparent"
                  aria-current="page"
                >
                  Dashbord
                </a>
              </li>
            </ul>
          </div>

          <button
            type="button"
            className=" mx-4 py-2 px-2 text-white bg-indigo-600 rounded-md"
            onClick={handleLogout}
          >
            Logout
          </button>
        </div>
      </nav>
    </>
  );
}
export default Dashboard;
